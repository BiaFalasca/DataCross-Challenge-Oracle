import csv
from datetime import datetime

QUANTIDADE_REGISTROS = 5
ARQUIVO_CSV = "prontuarios_gerados.csv"

ESQUEMA = [
    ("ID_PACIENTE", "int"),
    ("IDADE", "int"),
    ("SEXO", "char1"),
    ("ID_INTERNACAO", "int"),
    ("MUNICIPIO_REGIAO_DE_RESIDENCIA", "str"),
    ("DATA_DE_INTERNACAO", "date"),
    ("DATA_DE_SAIDA", "str"),
    ("STATUS", "str"),
    ("TEMPO_DE_PERMANENCIA_DIAS", "int"),
    ("TIPO_DE_INTERNACAO", "str"),
    ("NOME_DO_HOSPITAL", "str"),
    ("ID_DO_HOSPITAL", "int"),
    ("NIVEL_DE_ATENCAO", "str"),
    ("REGIAO_DO_HOSPITAL", "str"),
    ("SETOR_UNIDADE", "str"),
    ("DOENCA_DETECTADA", "str"),
    ("CID", "str"),
    ("VALOR_DIARIA_LEITO", "str"),
    ("NUMERO_TOTAL_DE_LEITOS_INSTALADOS", "int"),
    ("NUMERO_DE_LEITOS_OCUPADOS", "int"),
    ("NUMERO_DE_LEITOS_DISPONIVEIS", "int"),
    ("FC", "int"),
    ("FR", "int"),
    ("PAS", "int"),
    ("TEMP_AXILAR", "float"),
    ("SPO2", "int"),
    ("NIVEL_DE_CONSCIENCIA", "int"),
    ("DIURESE", "float"),
    ("GLICEMIA_CAPILAR", "int"),
    ("SONDA_VESICAL_DE_DEMORA", "str"),
    ("SONDA_NASOGASTRICA", "str"),
    ("SONDA_NASOENTERAL", "str"),
    ("CATETER_DE_O2", "str"),
    ("INTUBACAO_OROTRAQUEAL", "str"),
    ("VENTILACAO_MECANICA", "str"),
    ("CATETER_VENOSO_CENTRAL", "str"),
    ("CATETER_VENOSO_CENTRAL_DE_INSERCAO_PERIFERICA_PICC", "str"),
    ("CATETER_VENOSO_PERIFERICO", "str"),
    ("TC_POSITIVO_PARA_AVC", "str"),
    ("EEG_POSITIVO_PARA_AVC", "str"),
    ("VACINA_INFLUENZA", "str"),
    ("VACINA_COVID", "str"),
    ("HIPERTENSAO", "str"),
    ("DIABETES", "str"),
    ("SEQUELA_DE_AVC", "str"),
    ("FIBRILACAO_ATRIAL", "str"),
    ("INSUFICIENCIA_CARDIACA", "str"),
    ("DRC", "str"),
    ("OBESIDADE", "str"),
    ("NEOPLASIA", "str"),
    ("ANTIBIOTICO", "str"),
    ("DATA_DE_INICIO_ATB", "str"),
    ("DURACAO_ATB", "str"),
    ("PADRAO_TOMOGRAFIA", "str"),
    ("ETIOLOGIA_PNEUMONIA", "str"),
    ("TRATAMENTO_ETIOLOGICO", "str"),
    ("DPOC", "str"),
    ("DEMENCIA_ALZHEIMER", "str"),
    ("UROCULTURA", "str"),
    ("HPB", "str"),
    ("LITIASE_URINARIA", "str"),
    ("LEITOS_OCUPADOS_OUTRAS_DOENCAS", "int"),
    ("LEITOS_DESTINADOS_AVC_ITU_PNEUMONIA", "int"),
    ("TAXA_OCUPACAO_AVC_ITU_PNEUMONIA", "float"),
]

CAMPOS = [campo for campo, _ in ESQUEMA]


def converter_valor(texto, tipo):
    texto = texto.strip()

    if not texto:
        raise ValueError("O campo nao pode ficar vazio.")

    if tipo == "int":
        return int(texto)

    if tipo == "float":
        return float(texto.replace(",", "."))

    if tipo == "char1":
        if len(texto) != 1:
            raise ValueError("Digite exatamente um caractere.")
        return texto

    if tipo == "date":
        datetime.strptime(texto, "%Y-%m-%d")
        return texto

    return texto


def solicitar_campo(nome_campo, tipo):
    while True:
        try:
            valor = input(f"{nome_campo}: ")
            return converter_valor(valor, tipo)
        except ValueError as erro:
            print(f"Valor invalido: {erro}")


def solicitar_registro(numero, ids_internacao):
    print(f"\n=== REGISTRO {numero} DE {QUANTIDADE_REGISTROS} ===")
    registro = {}

    for campo, tipo in ESQUEMA:
        valor = solicitar_campo(campo, tipo)

        if campo == "ID_INTERNACAO":
            while valor in ids_internacao:
                print("ID_INTERNACAO ja utilizado. Digite outro.")
                valor = solicitar_campo(campo, tipo)

            ids_internacao.add(valor)

        registro[campo] = valor

    return registro


def gerar_registros():
    registros = []
    ids_internacao = set()

    for numero in range(1, QUANTIDADE_REGISTROS + 1):
        registro = solicitar_registro(numero, ids_internacao)
        registros.append(registro)

    return registros


def validar_registros(registros):
    if len(registros) < QUANTIDADE_REGISTROS:
        return False

    for registro in registros:
        if list(registro.keys()) != CAMPOS:
            return False

        for campo in CAMPOS:
            if str(registro[campo]).strip() == "":
                return False

    return True


def exibir_resumo(registros):
    print("\n=== RESUMO DOS REGISTROS ===")

    for indice, registro in enumerate(registros, start=1):
        print(
            f"{indice}. "
            f"ID_INTERNACAO={registro['ID_INTERNACAO']} | "
            f"DOENCA_DETECTADA={registro['DOENCA_DETECTADA']} | "
            f"CID={registro['CID']}"
        )


def gerar_csv(registros):
    with open(
        ARQUIVO_CSV,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as arquivo:
        escritor = csv.DictWriter(
            arquivo,
            fieldnames=CAMPOS
        )
        escritor.writeheader()
        escritor.writerows(registros)


def main():
    print("=== OPCAO 2 - GERADOR DE T_PRONTUARIOS ===")
    print(f"Campos solicitados por registro: {len(CAMPOS)}")

    registros = gerar_registros()

    if not validar_registros(registros):
        raise ValueError("Os cinco registros nao estao completos.")

    exibir_resumo(registros)
    gerar_csv(registros)

    print(f"\nRegistros completos armazenados: {len(registros)}")
    print(f"CSV gerado: {ARQUIVO_CSV}")


if __name__ == "__main__":
    main()
